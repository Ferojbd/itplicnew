#!/bin/sh

da license-set "$@"
